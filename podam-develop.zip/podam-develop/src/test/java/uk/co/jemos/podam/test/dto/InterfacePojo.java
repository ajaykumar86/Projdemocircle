/**
 * 
 */
package uk.co.jemos.podam.test.dto;

/**
 * An interface to test for errors
 * 
 * @author mtedone
 * 
 */
public interface InterfacePojo {

	void setIntField(int intField);

}
