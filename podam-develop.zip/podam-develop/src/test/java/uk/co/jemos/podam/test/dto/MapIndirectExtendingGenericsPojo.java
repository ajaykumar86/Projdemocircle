/**
 * 
 */
package uk.co.jemos.podam.test.dto;

/**
 * Test pojo
 * <p>
 * Pojo extending Pojo with generic type.
 * </p>
 * 
 * @author daivanov
 * 
 */
public class MapIndirectExtendingGenericsPojo extends MapExtendingGenericsPojo {
	private static final long serialVersionUID = 1L;
}
