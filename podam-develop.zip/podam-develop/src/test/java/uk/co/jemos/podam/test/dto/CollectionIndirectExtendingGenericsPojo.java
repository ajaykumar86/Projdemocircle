package uk.co.jemos.podam.test.dto;

public class CollectionIndirectExtendingGenericsPojo extends CollectionExtendingGenericsPojo {
	private static final long serialVersionUID = 1L;
}
