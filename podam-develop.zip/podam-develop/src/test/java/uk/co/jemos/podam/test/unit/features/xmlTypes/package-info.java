/**
 * Contains tests for XML types.
 * Created by tedonema on 21/06/2015.
 */
package uk.co.jemos.podam.test.unit.features.xmlTypes;